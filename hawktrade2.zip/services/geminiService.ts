
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { HistoricalPoint, TickerDetails, SentimentAnalysis, MorningBriefing } from "../types";

const ANALYSIS_CACHE_KEY = 'hawk_analysis_cache';

/**
 * Request Queue Manager
 * Ensures only one Gemini request is in flight at a time
 * and enforces a delay between requests to respect rate limits.
 */
class GeminiRequestQueue {
  private queue: Array<() => Promise<void>> = [];
  private isProcessing = false;
  private lastRequestTime = 0;
  private readonly STAGGER_DELAY = 2500; // 2.5 seconds between requests

  async add<T>(task: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      this.queue.push(async () => {
        try {
          // Calculate if we need to wait to satisfy the stagger delay
          const now = Date.now();
          const timeSinceLast = now - this.lastRequestTime;
          if (timeSinceLast < this.STAGGER_DELAY) {
            await new Promise(res => setTimeout(res, this.STAGGER_DELAY - timeSinceLast));
          }

          this.lastRequestTime = Date.now();
          const result = await task();
          resolve(result);
        } catch (error) {
          reject(error);
        }
      });
      this.process();
    });
  }

  private async process() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (this.queue.length > 0) {
      const currentTask = this.queue.shift();
      if (currentTask) {
        await currentTask();
      }
    }

    this.isProcessing = false;
  }
}

const geminiQueue = new GeminiRequestQueue();

// Helper to safely get the AI client
const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
};

// Exponential backoff helper
const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

async function callWithRetry<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const isRateLimit = error?.message?.includes('429') || error?.status === 'RESOURCE_EXHAUSTED';
    if (isRateLimit && retries > 0) {
      console.warn(`Rate limit hit despite queue. Retrying in ${delay}ms...`);
      await wait(delay);
      return callWithRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

export const getAIAnalysis = async (
  details: TickerDetails, 
  history: HistoricalPoint[]
): Promise<string> => {
  const ticker = details.ticker;
  
  // 1. Check Cache
  try {
    const cache = JSON.parse(localStorage.getItem(ANALYSIS_CACHE_KEY) || '{}');
    if (cache[ticker] && Date.now() - cache[ticker].timestamp < 60 * 60 * 1000) {
      return cache[ticker].text;
    }
  } catch (e) {}

  const ai = getAIClient();
  const model = 'gemini-3-flash-preview';
  
  const recentTrend = history.length > 0 
    ? history.slice(-5).map(h => `${h.date}: $${h.price}`).join(', ')
    : 'No recent history available';

  const prompt = `Provide a concise 2-paragraph financial analysis of ${details.name} (${details.ticker}). Market position and recent trend: ${recentTrend}.`;

  try {
    const response: GenerateContentResponse = await geminiQueue.add(() => 
      callWithRetry(() => ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature: 0.7,
          thinkingConfig: { thinkingBudget: 1024 }
        }
      }))
    );
    
    const analysis = response.text || "Analysis currently unavailable.";
    
    try {
      const cache = JSON.parse(localStorage.getItem(ANALYSIS_CACHE_KEY) || '{}');
      cache[ticker] = { text: analysis, timestamp: Date.now() };
      localStorage.setItem(ANALYSIS_CACHE_KEY, JSON.stringify(cache));
    } catch (e) {}

    return analysis;
  } catch (error) {
    console.error("Gemini analysis error:", error);
    return `Analysis for ${ticker} is currently paused to conserve API quota. Please try again in 60 seconds.`;
  }
};

export const askGemini = async (ticker: string, question: string): Promise<string> => {
  const ai = getAIClient();
  const prompt = `Ticker: ${ticker}. Question: ${question}. Provide a brief professional insight.`;
  
  try {
    const response: GenerateContentResponse = await geminiQueue.add(() => 
      callWithRetry(() => ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { 
          temperature: 0.4,
          thinkingConfig: { thinkingBudget: 1024 }
        }
      }))
    );
    return response.text || "No data returned.";
  } catch (err) {
    return "Gemini Terminal is queuing requests. Please wait a moment.";
  }
};

export const analyzeSentiment = async (ticker: string, text: string): Promise<SentimentAnalysis> => {
  const ai = getAIClient();
  const prompt = `Analyze sentiment for ${ticker}: "${text}". Return JSON.`;

  try {
    const response: GenerateContentResponse = await geminiQueue.add(() => 
      callWithRetry(() => ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: "You are a financial analyst. Return sentiment as JSON.",
          temperature: 0.1, 
          responseMimeType: "application/json",
          thinkingConfig: { thinkingBudget: 1024 },
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              ticker: { type: Type.STRING },
              score: { type: Type.NUMBER },
              label: { type: Type.STRING, enum: ["Bullish", "Bearish", "Neutral", "Volatile"] },
              confidence: { type: Type.NUMBER },
              reasoning: { type: Type.STRING }
            },
            required: ["ticker", "score", "label", "confidence", "reasoning"]
          }
        }
      }))
    );

    const result = JSON.parse(response.text || '{}');
    return {
      ticker: result.ticker ?? ticker,
      score: result.score ?? 0,
      label: (result.label as any) ?? 'Neutral',
      confidence: result.confidence ?? 0,
      reasoning: result.reasoning ?? 'Sentiment engine is cooling down.'
    };
  } catch (error) {
    return { ticker, score: 0, label: 'Neutral', confidence: 0.5, reasoning: 'Quota optimization active.' };
  }
};

export const getMorningBriefing = async (): Promise<MorningBriefing> => {
  const ai = getAIClient();
  const model = 'gemini-3-pro-preview';
  
  const prompt = `Generate a "HawkTrade Morning Briefing" with global news and 3 watch stocks. JSON format.`;

  try {
    const response: GenerateContentResponse = await geminiQueue.add(() => 
      callWithRetry(() => ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.3,
          responseMimeType: "application/json",
          thinkingConfig: { thinkingBudget: 4096 },
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              watchList: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    ticker: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                    prediction: { type: Type.STRING }
                  },
                  required: ["ticker", "rationale", "prediction"]
                }
              }
            },
            required: ["summary", "watchList"]
          }
        }
      }))
    );

    const data = JSON.parse(response.text || '{}');
    const sources: Array<{ title: string; uri: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web) sources.push({ title: chunk.web.title, uri: chunk.web.uri });
      });
    }

    return {
      summary: data.summary || "Markets are currently processing global inputs.",
      stocks: data.watchList || [],
      sources: sources.slice(0, 5),
      timestamp: Date.now()
    };
  } catch (error) {
    return {
      summary: "The Neural network is currently staggered to prevent quota limits. Reviewing historical benchmarks.",
      stocks: [{ ticker: 'SPY', rationale: 'Global benchmark.', prediction: 'Stable.' }],
      sources: [],
      timestamp: Date.now()
    };
  }
};
